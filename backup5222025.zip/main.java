public class main {

    public static void main(String[] args){
        
        GameManager game = new GameManager();
    
    
    }
}